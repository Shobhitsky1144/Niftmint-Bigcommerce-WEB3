export default function CustomRoot({ children }) {
  return <>{children}</>;
}
