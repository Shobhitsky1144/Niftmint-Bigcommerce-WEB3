// import Axios from "axios";
// import { API_BASE_URL, API_ROUTES } from "../constants/ApiBaseUrl";

// export const ApiHelper = async (collectionId, brandId, url) => {
//   try {
//     const res = await Axios.url(`${API_BASE_URL}${API_ROUTES.url}${id}`);
//     toast(res.data.message);
//   } catch (error) {
//     toast.error(error.response.data.message);
//   }
// };
