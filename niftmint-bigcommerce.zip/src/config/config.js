export const CAPTCHA_SITE_KEY = "6LcD4_seAAAAAJpl_V_eqq5iDvYSEeBnVhdBSw3v";
